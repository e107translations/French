<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/29 09:10:46
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_LASTSEEN_1", "Menu 'Vu dernièrement'");
define("LAN_ONLINE_TRACKING_MESSAGE", "Le suivi des utilisateurs en ligne est actuellement désactivé, veuillez l'activer [link=".e_ADMIN."users.php?options]ici[/link][br]");
define("LAN_ONLINE_1", "Invités :");
define("LAN_ONLINE_2", "Membres :");
define("LAN_ONLINE_3", "Sur cette page :");
define("LAN_ONLINE_4", "En ligne");
define("LAN_ONLINE_5", "");
define("LAN_ONLINE_6", "Nouveau membre :");
define("LAN_ONLINE_7", "Regardant");
define("LAN_ONLINE_8", "Record en ligne :");
define("LAN_ONLINE_9", "sur");
define("LAN_ONLINE_10", "Menu 'En ligne'");
define("LAN_ONLINE_11", "Nombre total de membres inscrits :");
define("LAN_ONLINE_ADMIN_1", "Menu 'Vu dernièrement'");
define("LAN_ONLINE_ADMIN_2", "Légende du menu 'Vu dernièrement'");
define("LAN_ONLINE_ADMIN_3", "Nombre d'enregistrements à afficher");
define("LAN_ONLINE_ADMIN_4", "menu 'En ligne'");
define("LAN_ONLINE_ADMIN_5", "Légende du menu 'En ligne'");
define("LAN_ONLINE_ADMIN_6", "Voir la liste des membres en ligne ?");
define("LAN_ONLINE_ADMIN_7", "Voir la liste étendue des membres en ligne ?");
define("LAN_ONLINE_ADMIN_8", "Affiche une liste des membres séparés par une virgule.");
define("LAN_ONLINE_ADMIN_9", "Affiche une liste des membres regardant une page.");
define("LAN_ONLINE_ADMIN_10", "Affiche les invités en ligne.");


?>