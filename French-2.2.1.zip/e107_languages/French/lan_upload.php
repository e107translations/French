<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Télécharger");
define("LAN_UL_001", "Adresse mail invalide");
define("LAN_UL_002", "Vous n'avez pas les autorisations appropriées pour télécharger des fichiers sur ce serveur.");
define("LAN_UL_020", "Erreur");
define("LAN_UL_021", "Échec de téléchargement");
define("LAN_UL_022", "Peut varier selon le type de fichier");
define("LAN_UL_023", "Type");
define("LAN_UL_024", "Taille maximale");
define("LAN_UL_025", "Téléchargements non autorisés");
define("LAN_UL_026", "");
define("LAN_UL_027", "");
define("LAN_UL_032", "Vous devez sélectionner une catégorie");
define("LAN_UL_033", "Vous devez entrer une adresse mail valide");
define("LAN_UL_034", "Vous devez spécifier le nom du fichier");
define("LAN_UL_035", "Vous devez entrer une description");
define("LAN_UL_036", "Vous devez spécifier le fichier à télécharger");
define("LAN_UL_037", "Vous devez spécifier une catégorie");
define("LAN_UL_038", "");
define("LAN_61", "Votre nom : ");
define("LAN_112", "Adresse mail : ");
define("LAN_144", "URL du site web : ");
define("LAN_402", "Vous devez être un membre enregistré pour télécharger des fichiers sur ce serveur.");
define("LAN_404", "Merci. Votre téléchargement sera examiné par un administrateur et publié sur le site, si considéré comme approprié.");
define("LAN_406", "Veuillez noter");
define("LAN_407", "Tout autre type de fichiers téléchargé sera immédiatement supprimé.");
define("LAN_408", "Souligné");
define("LAN_409", "Nom du fichier");
define("LAN_410", "Version");
define("LAN_411", "Fichier");
define("LAN_413", "Description");
define("LAN_414", "Démonstration opérationnelle");
define("LAN_415", "entrez l'URL d'un site où une démonstration peut être vue");
define("LAN_416", "Soumettre et télécharger");
define("LAN_417", "Télécharger le fichier");
define("LAN_418", "Taille de fichier maximale absolue :");
define("DOWLAN_11", "Catégorie");
define("LAN_419", "Types de fichiers autorisés");
define("LAN_420", "des champs sont obligatoires");
