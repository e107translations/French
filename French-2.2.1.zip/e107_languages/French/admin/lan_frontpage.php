<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/02/01 15:23:27
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("FRTLAN_13", "Paramètres de la page d'accueil");
define("FRTLAN_30", "Page personnalisée");
define("FRTLAN_35", "Page post-connexion");
define("FRTLAN_42", "Ajouter une nouvelle règle");
define("FRTLAN_43", "Classe");
define("FRTLAN_46", "Modifier une règle existante");
define("FRTLAN_49", "Page d'accueil");
define("FRTLAN_51", "Autre");
define("FRTLAN_PAGE_TITLE", "Page d'accueil");
define("FRTLAN_56", "Dupliquer la définition pour la classe :");
define("FRTLAN_57", "Erreur logicielle");
define("FRTLAN_61", "Sélection");


?>