<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PRINT_86", "Catégorie : ");
define("LAN_PRINT_87", "par ");
define("LAN_PRINT_94", "Publié par");
define("LAN_PRINT_135", "Article :");
define("LAN_PRINT_303", "Cet article est de ");
define("LAN_PRINT_305", "Sous-titre : ");
define("LAN_PRINT_306", "Document de : ");
define("LAN_PRINT_307", "Imprimer cette page");
define("LAN_PRINT_1", "Version imprimable");
