<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/22 11:10:20
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_LZ_THEMEPREF_00", "Image d'arrière-plan pour la vidéo [1920x1080px]");
define("LAN_LZ_THEMEPREF_01", "Image d'arrière-plan pour les appareils mobiles");
define("LAN_LZ_THEMEPREF_02", "Première image de la vidéo [1920x1080px]");
define("LAN_LZ_THEMEPREF_03", "URL vers la vidéo d'en-tête au format mp4");
define("LAN_LZ_THEMEPREF_04", "Emplacement de l'inscription/connexion");
define("LAN_LZ_THEMEPREF_05", "haut");
define("LAN_LZ_THEMEPREF_06", "bas");


?>