<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/01/30 11:34:18
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_USER_NAME", "Utilisateur");
define("LAN_PLUGIN_USER_DESC", "Menus de thème et de langue utilisateur");


?>