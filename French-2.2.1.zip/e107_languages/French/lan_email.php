<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/02/01 18:21:32
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_EMAIL_1", "De :");
define("LAN_EMAIL_2", "Adresse IP de l'expéditeur :");
define("LAN_EMAIL_3", "Article par mail de");
define("LAN_EMAIL_4", "Envoyer par mail");
define("LAN_EMAIL_5", "Envoyer à un(e) ami(e)");
define("LAN_EMAIL_6", "J'ai pensé que tu pourrais être intéressé(e) par cet article de");
define("LAN_EMAIL_7", "Envoyer un mail à quelqu'un");
define("LAN_EMAIL_8", "Commentaire");
define("LAN_EMAIL_9", "Désolé - impossible d'envoyer le mail");
define("LAN_EMAIL_10", "Mail envoyé à :");
define("LAN_EMAIL_11", "Mail envoyé");
define("LAN_EMAIL_13", "Envoyer l'article par mail à un(e) ami(e)");
define("LAN_EMAIL_14", "Envoyer l'élément d'article par mail à un(e) ami(e)");
define("LAN_EMAIL_15", "Nom d'utilisateur :");
define("LAN_EMAIL_106", "Cela ne semble pas être une adresse email valide");
define("LAN_EMAIL_185", "Envoyer l'article");
define("LAN_EMAIL_186", "Envoyer l'élément d'article");
define("LAN_EMAIL_187", "Mail du destinataire");
define("LAN_EMAIL_188", "J'ai pensé que tu pourrais être intéressé(e) par cette histoire de nouvelles de");
define("LAN_EMAIL_189", "J'ai pensé que tu pourrais être intéressé(e) par cet article de");
define("LAN_EMAIL_190", "Entrez le code visible");
define("LAN_SOCIAL_LINK_CHK", "Consultez ce lien :");


?>