<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/14 10:08:40
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("NLLAN_04", "L'extension du bulletin d'informations a été installée avec succès. Pour la configuration, retournez à la page d'administration principale et cliquez sur 'bulletin d'informations' dans la section extensions.");
define("NLLAN_05", "Aucun bulletin d'informations défini actuellement");
define("NLLAN_07", "Abonnés");
define("NLLAN_10", "Bulletins d'informations existants");
define("NLLAN_11", "Aucune publication de bulletin d'informations actuellement.");
define("NLLAN_12", "Publication");
define("NLLAN_13", "[ ID parent ] Sujet/Titre");
define("NLLAN_14", "Publier ?");
define("NLLAN_17", "Non envoyé - cliquez pour envoyer");
define("NLLAN_18", "Êtes-vous sûr de vouloir envoyer cette publication  aux abonnés ?");
define("NLLAN_19", "Êtes-vous sûr de que vouloir supprimer cette publication du bulletin d'informations ?");
define("NLLAN_20", "Publicationss existants");
define("NLLAN_23", "En-tête");
define("NLLAN_24", "Pied de page");
define("NLLAN_30", "Bulletin d'informations");
define("NLLAN_31", "Sujet / Titre");
define("NLLAN_32", "Numéro de publication");
define("NLLAN_33", "Texte");
define("NLLAN_36", "Mettre à jour la publication du bulletin d'informations");
define("NLLAN_37", "Créer une publication du bulletin d'informations");
define("NLLAN_39", "Publication du bulletin d'informations enregistrée dans la base de données - pour l'envoyer, cliquez sur le bouton 'Émission de publication' dans le menu Options.");
define("NLLAN_40", "Envoi ajouté à la file d'attente des envois - publication envoyée à [x] abonnés.");
define("NLLAN_41", "Aucun abonné trouvé - envoi annulé");
define("NLLAN_44", "Page principale du bulletin d'informations");
define("NLLAN_45", "Créer un bulletin d'informations");
define("NLLAN_46", "Créer une liste de mails");
define("NLLAN_47", "Options du bulletin d'informations");
define("NLLAN_48", "Abonnés au bulletin d'informations");
define("NLLAN_49", "Bulletin d'informations :");
define("NLLAN_54", "Envoyer");
define("NLLAN_56", "ID de bulletin d'informations non disponible");
define("NLLAN_62", "L'utilisateur est exclu ! (ou non complètement inscrit)");
define("NLLAN_63", "Nombre total d'abonnés");
define("NLLAN_64", "Retour à la page d'accueil du bulletin d'informations");
define("NLLAN_65", "Vue d'ensemble des abonnés au bulletin d'informations ID");
define("NLLAN_66", "Votre liste d'abonnés au bulletin d'informations a été nettoyée.");
