<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/01/09 14:35:50
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LIST_NEW_NAME", "Liste de nouveaux articles");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "Cette extension vous permet d'afficher une liste et/ou un menu des ajouts récents dans toutes les catégories e107. Vous pouvez afficher la liste avec des données depuis votre dernière visite ou afficher une liste générale des derniers ajouts.");
