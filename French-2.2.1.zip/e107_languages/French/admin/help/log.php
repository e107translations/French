<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Activez les statistiques à partir de cette page. Si vous avez peu d'espace disque, cochez 'Domaine seulement';pour le référent, cela enregistrera seulement le domaine par opposition à l'url complète, c'est-à-dire, 'jalist.com' au lieu de ' http: // jalist.com/links.php ";
  $ns -> tablerender("Aide", $text);
  ?>
