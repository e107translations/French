<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("POLL_ADLAN03", "Configurer les sondages");
define("POLL_ADLAN04", "L'extension sondage a été installée avec succès. Pour ajouter des sondages, cliquez sur l'icône des sondages dans la section extensions de la page d'administration et n'oubliez pas d'activer l'élément de menu de votre page de menus.");
define("POLL_ADLAN05", "Sondage principal :");
define("POLL_ADLAN06", "Sujet du forum :");
define("POLL_ADLAN07", "Type");
define("POLLAN_MENU_CAPTION", "Sondage");
define("POLLAN_7", "Aucun sondage actuellement.");
define("LAN_AL_POLL_01", "Sondage supprimé");
define("LAN_AL_POLL_02", "Sondage mis à jour");
define("LAN_AL_POLL_03", "Sondage ajouté");
define("LAN_AL_POLL_04", "");
define("LAN_AL_POLL_05", "");
