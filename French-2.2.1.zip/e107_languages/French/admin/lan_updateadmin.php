<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UDALAN_1", "Erreur - veuillez re-soumettre.");
define("UDALAN_2", "Mise à jour des paramètres administrateur");
define("UDALAN_3", "Mise à jour des paramètres pour");
define("UDALAN_4", "Nom");
define("UDALAN_6", "Ressaisir le mot de passe");
define("UDALAN_7", "Changer le mot de passe");
define("UDALAN_8", "Mot de passe mis à jour pour");
