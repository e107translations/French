<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_PM_ADM_01", "Messagerie privée: préférences par défaut utilisées");
define("LAN_AL_PM_ADM_02", "Messagerie privée: préférences mises à jour");
define("LAN_AL_PM_ADM_03", "Messagerie privée : maintenance de la base de données complète");
define("LAN_AL_PM_ADM_04", "Messagerie privée : maintenance de la base de données démarrée");
define("LAN_AL_PM_ADM_05", "Messagerie privée : limite ajoutée");
define("LAN_AL_PM_ADM_06", "Messagerie privée : limite mise à jour");
define("LAN_AL_PM_ADM_07", "Messagerie privée : limite supprimée");
define("LAN_AL_PM_ADM_08", "Messagerie privée : erreur dans la création d'une valeur limite");
define("LAN_AL_PM_ADM_09", "Messagerie privée : erreur dans la mise à jour de la valeur limite");
define("LAN_AL_PM_ADM_10", "Messagerie privée : erreur dans la suppression de la valeur limite");
