<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("MESSLAN_1", "Messages reçus");
define("MESSLAN_2", "Supprimer le message");
define("MESSLAN_3", "Message supprimé.");
define("MESSLAN_4", "Supprimer tous les messages");
define("MESSLAN_5", "Confirmer");
define("MESSLAN_6", "Tous les messages ont été supprimés.");
define("MESSLAN_7", "Pas de message.");
define("MESSLAN_8", "Type de message");
define("MESSLAN_9", "Signalé le");
define("MESSLAN_10", "Soumis par");
define("MESSLAN_11", "s'ouvre dans une nouvelle fenêtre");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Lien");
