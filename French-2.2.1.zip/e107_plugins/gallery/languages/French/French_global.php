<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/20 17:20:19
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_GALLERY_TITLE", "Galerie");
define("LAN_PLUGIN_GALLERY_DIZ", "Une simple galerie d'images");
define("LAN_PLUGIN_GALLERY_SEF_01", "SEF galerie");
define("LAN_PLUGIN_GALLERY_SEF_02", "URL SEF activées.");
define("LAN_PLUGIN_GALLERY_SEF_03", "URL SEF désactivées.");
define("LAN_PLUGIN_GALLERY_SEF_04", "Galerie par défaut");


?>