<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("US_LAN_1", "Sélectionner un utilisateur");
define("US_LAN_2", "Sélectionner un groupe d'utilisateurs");
define("US_LAN_3", "Tous les utilisateurs");
define("US_LAN_4", "Trouver un nom d'utilisateur");
define("US_LAN_5", "Utilisateur(s) trouvé(s)");
define("US_LAN_6", "Recherche");
