<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_FEATUREBOX_NAME", "Ils sont à l'affiche");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Affiche une zone animée sur le haut de votre page avec les articles et autres contenus que vous souhaitez mettre en avant.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Créer un élément de boîte de fonction");
define("FBLAN_INSTALL_01", "Ajouter une table de données de catégorie par défaut.");
define("FBLAN_INSTALL_02", "Ajouter une table de données par défaut.");
define("FBLAN_INSTALL_03", "Non assigné");
define("FBLAN_INSTALL_04", "Carrousel");
define("FBLAN_INSTALL_05", "Onglets");
