<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_POLL_NAME", "Sondage");
define("LAN_PLUGIN_POLL_DESCRIPTION", "L'extension sondage vous permet de mettre en place des sondages soit dans un menu ou dans un message du forum.");
