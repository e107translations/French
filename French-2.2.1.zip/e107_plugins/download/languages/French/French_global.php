<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_DOWNLOAD_NAME", "Téléchargements");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "Cette extension est un système complet de téléchargement de fichiers");
