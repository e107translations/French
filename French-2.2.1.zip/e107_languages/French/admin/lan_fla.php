<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FLALAN_2", "Aucune échec de tentative de connexion n'a été consigné");
define("FLALAN_3", "Tentative(s) supprimée(s)");
define("FLALAN_4", "L'utilisateur a tenté de se connecter en utilisant un nom d'utilisateur/mot de passe incorrect");
define("FLALAN_5", "IP(s) exclue(s)");
define("FLALAN_7", "Données");
define("FLALAN_8", "Adresse IP/Nom de domaine");
define("FLALAN_10", "Supprimer/exclure les entrées sélectionnées");
define("FLALAN_15", "L'(les) adresse(s) IP suivante(s) a(ont) été automatiquement exclue(s) - l'utilisateur ayant échoué à plus de 10 tentatives de connexion");
define("FLALAN_16", "supprimer cette liste d'exclusion automatique");
define("FLALAN_17", "Liste d'exclusion automatique supprimée");
define("FLALAN_18", "Exclusion de l'adresse IP --IP-- non effectuée car étant sur liste blanche");
