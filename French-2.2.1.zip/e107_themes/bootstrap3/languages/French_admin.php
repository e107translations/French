<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/20 18:46:16
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_THEMEPREF_00", "Image de marque :");
define("LAN_THEMEPREF_01", "Alignement de la barre de navigation");
define("LAN_THEMEPREF_02", "Emplacement de l'Inscription/Connexion");
define("LAN_THEMEPREF_03", "Styles de bootswatch :");
define("LAN_THEMEPREF_04", "Nom du site");
define("LAN_THEMEPREF_05", "Logo");
define("LAN_THEMEPREF_06", "Logo &amp; Nom du site");
define("LAN_THEMEPREF_07", "gauche");
define("LAN_THEMEPREF_08", "droite");
define("LAN_THEMEPREF_09", "haut");
define("LAN_THEMEPREF_10", "bas");


?>