<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/09/25 11:13:03
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_FORUM_MENU_001", "Publié par");
define("LAN_FORUM_MENU_002", "Aucun message actuellement");
define("LAN_FORUM_MENU_003", "Nouvelle configuration du menu des messages du forum entregistrée");
define("LAN_FORUM_MENU_004", "Légende");
define("LAN_FORUM_MENU_005", "Nombre de messages à afficher ?");
define("LAN_FORUM_MENU_006", "Nombre de caractères à afficher ?");
define("LAN_FORUM_MENU_007", "Suffixe pour des messages trop longs ?");
define("LAN_FORUM_MENU_008", "Afficher les sujets originaux dans le menu ?");
define("LAN_FORUM_MENU_009", "Mettre à jour les paramètres du menu");
define("LAN_FORUM_MENU_012", "Age maximum des messages affichés");
define("LAN_FORUM_MENU_013", "Utilisez zéro sur un site calme; définir une valeur en jours réduira le temps de base de données sur un site occupé");
define("LAN_FORUM_MENU_014", "Hauteur de calque de défilement (en pixels)");
define("LAN_FORUM_MENU_015", "Laissez vide pour aucun défilement");
define("LAN_FORUM_MENU_016", "Aucune catégorie de forum n'a encore été créée !");
