<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_GSMAP_01", "Importer des liens de site");
define("LAN_AL_GSMAP_02", "Lien du plan de site supprimé");
define("LAN_AL_GSMAP_03", "Lien du plan de site ajouté");
define("LAN_AL_GSMAP_04", "Lien du plan de site mis à jour");
