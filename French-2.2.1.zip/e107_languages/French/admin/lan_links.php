<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/20 11:11:38
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LCLAN_19", "Type d'ouverture du lien");
define("LCLAN_20", "S'ouvre dans la même fenêtre");
define("LCLAN_23", "S'ouvre dans une nouvelle fenêtre");
define("LCLAN_24", "S'ouvre dans une mini-fenêtre 600x400");
define("LCLAN_78", "Afficher la description comme info-bulle");
define("LCLAN_79", "Afficher la description lorsque la souris survole le lien");
define("LCLAN_80", "Activer les sous-menus extensibles");
define("LCLAN_81", "Les sous-menus s'afficheront uniquement après avoir cliqué sur le lien parent. (Le lien parent est désactivé)");
define("LCLAN_105", "Fonction");
define("LCLAN_106", "Détenu par");
define("LCLAN_107", "Permettre de substituer l'URL avec l'URL SEF créée dynamiquement");
define("LCLAN_108", "Certaines sélections omises - vous ne pouvez définir le lien comme un sous-lien de ses sous-lien.");
define("LCLAN_109", "Veuillez choisir un parent");
define("LCLAN_110", "Veuillez choisir un module générateur");
define("LCLAN_111", "Données du module générateur non valides");
define("LINKLAN_1", "S'ouvre dans une fenêtre de 800x600");
define("LINKLAN_4", "Générateur de sous-liens");
define("LINKLAN_5", "Générer les sous-liens");
define("LINKLAN_6", "Créer des sous-liens depuis");
define("LINKLAN_7", "Créer des sous-liens sous quel lien ?");
define("LINKLAN_8", "Catégories d'articles");
define("LINKLAN_9", "Catégories de téléchargements");
define("LINKLAN_10", "Raccourcis de thème");


?>