<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2018/05/14 14:32:33
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Publications de l'utilisateur");
define("UP_LAN_0", "Toutes les publications du forum pour [x]");
define("UP_LAN_1", "Tous les commentaires pour [x]");
define("UP_LAN_2", "Discussion");
define("UP_LAN_3", "Vues");
define("UP_LAN_4", "Réponses");
define("UP_LAN_5", "Dernière publication");
define("UP_LAN_6", "Sujets");
define("UP_LAN_7", "Aucun commentaire");
define("UP_LAN_8", "Aucune publication");
define("UP_LAN_9", " le");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Publié le");
define("UP_LAN_12", "Recherche");
define("UP_LAN_14", "Publications du forum");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Adresse IP");
