<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/01/10 10:43:53
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_EFORM_001", "Cliquer sur l'avatar pour le changer");
define("LAN_EFORM_002", "Choisir un avatar");
define("LAN_EFORM_003", "OU");
define("LAN_EFORM_004", "Choisir cet avatar");
define("LAN_EFORM_005", "Aucun avatar disponible");
define("LAN_EFORM_006", "Note pour les administrateurs seulement :[br] le dossier [b][x][/b] est vide.[br]Téléchargez quelques images avatars par défaut dans ce dossier pour que les utilisateurs puissent y choisir un avatar.");
define("LAN_EFORM_007", "Gestionnaire de médias");
define("LAN_EFORM_008", "Choisissez les colonnes à afficher");
define("LAN_EFORM_009", "Afficher les colonnes");
define("LAN_EFORM_010", "Aperçu rapide");
define("LAN_EFORM_011", "Aller vers le profil utilisateur");
define("LAN_EFORM_012", "Champ multi-langue");
define("LAN_EFORM_013", "aller à la liste");
define("LAN_EFORM_014", "créer un autre");
define("LAN_EFORM_015", "modifier l'actuel");
define("LAN_EFORM_016", "Après soumission :");


?>