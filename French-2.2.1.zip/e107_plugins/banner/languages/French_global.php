<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_BANNER_NAME", "Bannières");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "Ajouter des bannières publicitaires à votre site e107");
