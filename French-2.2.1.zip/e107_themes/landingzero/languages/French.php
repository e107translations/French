<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/22 11:07:57
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_LZ_THEME_00", "Ok");
define("LAN_LZ_THEME_01", "Commencer");
define("LAN_LZ_THEME_02", "Basculer la vidéo");
define("LAN_LZ_THEME_03", "Votre navigateur ne prend pas en charge la balise vidéo. Je vous suggère de mettre à jour votre navigateur.");
define("LAN_LZ_THEME_04", "Dispositions flexibles");
define("LAN_LZ_THEME_05", "Fermer");
define("LAN_LZ_THEME_06", "Caractéristiques");
define("LAN_LZ_THEME_07", "Veuillez saisir un message.");
define("LAN_LZ_THEME_08", "Numéro de téléphone");
define("LAN_LZ_THEME_09", "Veuillez saisir votre numéro de téléphone.");
define("LAN_LZ_THEME_10", "Suivre");
define("LAN_LZ_THEME_11", "Téléphone");
define("LAN_LZ_THEME_12", "Votre message ici ...");
define("LAN_LZ_THEME_13", "Entrer en contact");
define("LAN_LZ_THEME_14", "Nous aimons les retours. Remplissez le formulaire ci-dessous et nous vous rappellerons dès que possible.");
define("LAN_LZ_THEME_15", "Dites-nous votre mail");
define("LAN_LZ_THEME_16", "Abonnez-vous aux mises à jour");
define("LAN_LZ_THEME_17", "Rester informé");
define("LAN_LZ_THEME_18", "VOUS POURRIEZ AUSSI AIMER");


?>