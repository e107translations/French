<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UTHEME_MENU_L1", "Définir");
define("UTHEME_MENU_L2", "Sélectionner une langue");
define("UTHEME_MENU_L3", "tables");
define("LAN_UMENU_THEME_1", "Définir le thème");
define("LAN_UMENU_THEME_2", "Sélectionnez le thème");
define("LAN_UMENU_THEME_3", "utilisateur :");
define("LAN_UMENU_THEME_4", "Activez ces thèmes pour que les utilisateurs puissent les sélectionner");
define("LAN_UMENU_THEME_5", "Mise à jour");
define("LAN_UMENU_THEME_6", "Thèmes disponibles pour les utilisateurs");
define("LAN_UMENU_THEME_7", "Groupe qui peut choisir des thèmes");
define("LAN_UMENU_THEME_8", "Thèmes autorisés : ");
define("LAN_UMENU_THEME_9", "Groupe qui peut choisir des thèmes : ");
