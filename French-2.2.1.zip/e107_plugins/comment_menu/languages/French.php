<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CM_L1", "Aucun commentaire actuellement.");
define("CM_L2", "");
define("CM_L3", "Légende");
define("CM_L4", "Nombre de commentaires à afficher ?");
define("CM_L5", "Nombre de caractères à afficher ?");
define("CM_L6", "Suffixe pour les commentaires trop longs ?");
define("CM_L7", "Afficher le titre original des articles dans le menu ?");
define("CM_L8", "Nouvelle configuration du menu des commentaires");
define("CM_L11", "sur");
define("CM_L12", "Re:");
define("CM_L13", "Publié par");
