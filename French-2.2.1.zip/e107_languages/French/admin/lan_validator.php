<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_VALIDATE_0", "Erreur inconnue");
define("LAN_VALIDATE_101", "Valeur manquante");
define("LAN_VALIDATE_102", "Type de valeur inattendu");
define("LAN_VALIDATE_103", "Caractères non valides trouvés");
define("LAN_VALIDATE_104", "Adresse email non valide");
define("LAN_VALIDATE_105", "Les champs ne correspondent pas");
define("LAN_VALIDATE_131", "Chaîne trop courte");
define("LAN_VALIDATE_132", "Chaîne trop longue");
define("LAN_VALIDATE_133", "Nombre trop faible");
define("LAN_VALIDATE_134", "Nombre trop élevé");
define("LAN_VALIDATE_135", "Nombre de valeurs de tableau trop faible");
define("LAN_VALIDATE_136", "Nombre de valeurs de tableau trop élevé");
define("LAN_VALIDATE_151", "Nombre de type entier attendu");
define("LAN_VALIDATE_152", "Nombre de type décimal attendu");
define("LAN_VALIDATE_153", "Type instance attendu");
define("LAN_VALIDATE_154", "Type tableau attendu");
define("LAN_VALIDATE_191", "Valeur manquante");
define("LAN_VALIDATE_201", "Le fichier n'existe pas");
define("LAN_VALIDATE_202", "Fichier non accessible en écriture");
define("LAN_VALIDATE_203", "La taille du fichier dépasse la taille de fichier autorisée");
define("LAN_VALIDATE_204", "La taille du fichier est inférieure à la taille de fichier minimale admise");
define("LAN_VALIDATE_FAILMSG", "[x] erreur de validation : [y] [z].");
