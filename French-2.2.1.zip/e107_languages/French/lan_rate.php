<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/01/02 16:12:07
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("RATELAN_0", "Vote");
define("RATELAN_1", "Votes");
define("RATELAN_2", "Comment jugez-vous ce point ?");
define("RATELAN_3", "Merci d'avoir voté !");
define("RATELAN_4", "Non évalué");
define("RATELAN_5", "Évaluer ceci :");
define("RATELAN_6", "Connectez-vous pour évaluer ceci.");
define("RATELAN_7", "Aimer");
define("RATELAN_8", "Ne pas aimer");
define("RATELAN_9", "Vous avez déjà voté");
define("RATELAN_10", "Il n'y a pas d'ID d'élément dans la note");
define("RATELAN_11", "La notation a échoué");
define("RATELAN_POOR", "Pauvre");
define("RATELAN_FAIR", "Juste");
define("RATELAN_GOOD", "Bien");
define("RATELAN_VERYGOOD", "Très bien");
define("RATELAN_EXCELLENT", "Excellent");


?>