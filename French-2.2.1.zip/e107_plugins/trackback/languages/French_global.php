<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/02/01 18:50:18
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TRACKBACK_NAME", "Rétrolien");
define("LAN_PLUGIN_TRACKBACK_DESCRIPTION", "Cette extension vous permet d'utiliser les r�troliens dans vos publications d'articles.");


?>