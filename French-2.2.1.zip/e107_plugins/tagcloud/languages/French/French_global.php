<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2019/05/10 09:07:58
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TAGCLOUD_NAME", "Nuage de mots-clés");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", "Un simple menu de mots-clés pour votre site web e107.");
