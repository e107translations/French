<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/14 10:11:23
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_EC_PM_04", "Gestionnaire de messagerie privée");
define("LAN_EC_PM_05", "Processus d'envois importants de messages privés");
define("LAN_EC_PM_06", "Commencer le traitement en vrac de la messagerie privée pour [y] bénéficiaires");
