<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Administrateur principal");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "sortie le");
define("FOOTLAN_5", "Thème de l'administration");
define("FOOTLAN_6", "par");
define("FOOTLAN_7", "Information");
define("FOOTLAN_8", "Date d'installation");
define("FOOTLAN_9", "Serveur");
define("FOOTLAN_10", "Nom de domaine");
define("FOOTLAN_11", "Version de PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informations sur le site");
define("FOOTLAN_14", "Afficher la documentation");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Base de données");
define("FOOTLAN_17", "Jeu de caractères");
define("FOOTLAN_18", "Thème du site");
define("FOOTLAN_19", "Heure du serveur");
define("FOOTLAN_20", "Niveau de sécurité");
