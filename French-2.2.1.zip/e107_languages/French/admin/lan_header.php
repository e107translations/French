<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_HEADER_01", "Menu d'administration");
define("LAN_HEADER_02", "Votre serveur n'autorise pas les téléchargements HTTP de fichiers et il ne sera donc pas possible aux membres de télécharger des avatars/fichiers etc. Pour remédier à ceci, déclarez la variable <strong>file_uploads</strong> à <strong>On</strong> dans votre fichier <strong>php.ini</strong> et redémarrez votre serveur. Si vous n'avez pas accès à votre fichier php.ini contact votre hébergeur.");
define("LAN_HEADER_03", "Votre serveur s'exécute avec une restriction du <q>basedir</q>. Cela interdit l'utilisation de tout fichier en dehors de votre répertoire d'accueil et peut ainsi affecter certains scripts comme le gestionnaire de fichiers.");
define("LAN_HEADER_04", "Zone d'administration");
define("LAN_HEADER_05", "langue affichée dans la zone d'administration");
define("LAN_HEADER_06", "Informations sur les extensions");
