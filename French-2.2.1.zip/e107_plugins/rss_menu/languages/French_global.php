<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/02/01 18:50:00
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_RSS_NAME", "RSS");
define("LAN_PLUGIN_RSS_DESCRIPTION", "Flux RSS de votre site.");
define("LAN_PLUGIN_RSS_SUBSCRIBE", "S'abonner");
define("LAN_PLUGIN_RSS_SUBSCRIBE_TO", "S'abonner à&nbsp;[x]");


?>