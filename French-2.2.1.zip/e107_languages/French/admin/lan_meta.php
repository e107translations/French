<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("METLAN_00", "Balises méta");
define("METLAN_1", "Balises meta supplémentaires");
define("METLAN_2", "par exemple < meta name='revisit-after' content='30 days' />");
define("METLAN_3", "Utiliser le titre des articles et le résumé comme méta-description pour les pages d'articles.");
