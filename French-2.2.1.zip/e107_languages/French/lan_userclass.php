<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/14 09:38:43
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("UC_LAN_0", "Tout le monde (public)");
define("UC_LAN_1", "Invités");
define("UC_LAN_2", "Personne (inactif)");
define("UC_LAN_3", "Membres");
define("UC_LAN_4", "Lecture seule");
define("UC_LAN_5", "Administrateur");
define("UC_LAN_6", "Administrateur principal");
define("UC_LAN_7", "Modérateurs du Forum");
define("UC_LAN_8", "Administrateurs et modérateurs");
define("UC_LAN_9", "Nouveaux utilisateurs");
define("UC_LAN_10", "Robots de recherche");
define("UC_LAN_INVERT", "Excepté [x]");
define("UC_LAN_INVERTLABEL", "Tout le monde sauf ...");
