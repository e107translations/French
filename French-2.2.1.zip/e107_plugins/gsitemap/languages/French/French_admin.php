<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("GSLAN_1", "Lien du site");
define("GSLAN_2", "Importer ?");
define("GSLAN_7", "Importer des liens");
define("GSLAN_8", "Importer avec :");
define("GSLAN_9", "Priorité");
define("GSLAN_10", "Fréquence");
define("GSLAN_11", "toujours");
define("GSLAN_12", "toutes les heures");
define("GSLAN_13", "tous les jours");
define("GSLAN_14", "toutes les semaines");
define("GSLAN_15", "tous les mois");
define("GSLAN_16", "tous les ans");
define("GSLAN_18", "Importer les liens cochés");
define("GSLAN_20", "Liste");
define("GSLAN_21", "Instructions");
define("GSLAN_22", "Créer une nouvelle entrée");
define("GSLAN_23", "Importer");
define("GSLAN_24", "Entrées de Google Sitemap");
define("GSLAN_27", "Dernière modification");
define("GSLAN_28", "Fréquence");
define("GSLAN_29", "Configuration de Google Sitemap");
define("GSLAN_32", "Comment utiliser Google Sitemap ?");
define("GSLAN_33", "Instructions de Google Sitemap");
define("GSLAN_34", "Commencez par créer les liens que vous souhaitez voir apparaître dans votre plan de site. Vous pouvez importer la plupart de vos liens en cliquant sur le bouton 'Importer' sur la droite");
define("GSLAN_35", "Si vous avez choisi d'importer vos liens, cliquez sur 'Importer' et vérifier ensuite les liens que vous souhaitez importer");
define("GSLAN_36", "Vous pouvez également entrer manuellement des liens individuels en cliquant sur 'Créer une nouvelle entrée'");
define("GSLAN_37", "Une fois que vous avez quelques entrées, visitez le site [URL] et saisissez l'URL suivante -> <b>". SITEURL."gsitemap.php</b> - si cette URL ne vous semble pas correcte, veuillez vous assurer que l'URL de votre site est correctement renseignée dans la partie administration -> préférences");
define("GSLAN_38", "Pour plus d'informations sur le protocole Google Sitemap, consultez [URL].");
define("GSLAN_39", "Aucun lien dans le plan du site - importer des liens de site ?");
