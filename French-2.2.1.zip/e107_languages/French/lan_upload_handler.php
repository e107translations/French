<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANUPLOAD_1", "Le type de fichier");
define("LANUPLOAD_2", "n'est pas autorisé et a été supprimé.");
define("LANUPLOAD_3", "Téléchargement réussi");
define("LANUPLOAD_4", "Soit le dossier de destination n'existe pas, soit il n'est pas accessible en écriture (chmod 777).");
define("LANUPLOAD_5", "Le fichier téléchargé excède la valeur indiquée par la variable upload_max_filesize de php.ini.");
define("LANUPLOAD_6", "Le fichier téléchargé excède la directive MAX_FILE_SIZE qui a été spécifiée dans le formulaire html.");
define("LANUPLOAD_7", "Le fichier téléchargé n'a été que partiellement téléchargé.");
define("LANUPLOAD_8", "Aucun fichier n'a été téléchargé.");
define("LANUPLOAD_9", "Taille du fichier téléchargé de 0 octets");
define("LANUPLOAD_10", "Le téléchargement a échoué [Nom de fichier en doublon] - Il existe déjà un fichier portant le même nom.");
define("LANUPLOAD_11", "Le fichier n'a pas été téléchargé. Nom du fichier : ");
define("LANUPLOAD_13", "Le dossier temporaire est manquant");
define("LANUPLOAD_14", "L'écriture de fichier a échoué");
define("LANUPLOAD_15", "Téléchargement non autorisé");
define("LANUPLOAD_16", "Erreur inconnue");
define("LANUPLOAD_17", "Le nom du fichier téléchargé n'est pas valide");
define("LANUPLOAD_18", "Le fichier téléchargé dépasse les limites admissibles.");
define("LANUPLOAD_19", "Trop de fichiers téléchargés - l'excédent a été supprimé.");
