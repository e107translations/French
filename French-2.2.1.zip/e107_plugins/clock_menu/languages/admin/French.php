<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("CLOCK_AD_L2", "Légende");
define("CLOCK_AD_L4", "Configuration du menu horloge");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Si activé, il affichera l'heure au format US (type 0-12 pour AM/PM). Désactivé, il affichera un format 'militaire' de type 0-24");
define("CLOCK_AD_L7", "Préfixe de date");
define("CLOCK_AD_L8", "Si votre langue nécessite un petit mot avant la date (par exemple 'le' en français ou 'den' en allemand ...), utilisez ce champ. Si ce n'est pas nécessaire, laissez vide.");
define("CLOCK_AD_L9", "Suffixe 1");
define("CLOCK_AD_L10", "Suffixe 2");
define("CLOCK_AD_L11", "Suffixe 3");
define("CLOCK_AD_L12", "Suffixe 4 et plus");
define("CLOCK_AD_L13", "Si votre langue nécessite d'afficher un suffixe juste après les chiffres de la date, remplissez ces champs avec le suffixe seulement (exemple: 'st' pour 1, 'nd' pour 2, 'rd' pour 3 et 'th' pour 4 et plus - pour les utilisateurs anglais). Si ce n'est pas nécessaire laissez vide.");
