<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/23 11:19:28
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_SOCIAL_000", "Partager sur [x]");
define("LAN_SOCIAL_001", "Aimer sur [x]");
define("LAN_SOCIAL_002", "Envoyer par mail à quelqu'un");
define("LAN_SOCIAL_003", "+1 sur Google");
define("LAN_SOCIAL_004", "Ajouter à [x]");
define("LAN_SOCIAL_005", "Consultez ce lien :");
define("LAN_SOCIAL_100", "Impossible d'afficher le flux. L'identifiant de l'application Facebook n'a pas été défini dans les préférences.");
define("LAN_SOCIAL_200", "Impossible d'afficher le flux. L'URL Twitter n'a pas été définie dans les préférences.");
define("LAN_SOCIAL_201", "Tweets par");
define("LAN_SOCIAL_202", "Publier sur Twitter");
define("LAN_SOCIAL_203", "Écrivez votre tweet ici.");
define("LAN_SOCIAL_204", "Partager");
define("LAN_SOCIAL_205", "Impossible de rendre des commentaires. Il manque l'identifiant d'application Facebook.");
define("LAN_SOCIAL_WARNING", "Les commentaires de Facebook exigent que vous ayez un identifiant d'application Facebook. Consultez la zone 'connexion sociale' dans les préférences d'administration pour en ajouter une.");


?>