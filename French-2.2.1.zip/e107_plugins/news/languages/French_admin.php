<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/03/06 09:48:45
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LAN_NEWS_ADMIN_00", "Dernières éléments d'actualités");
define("LAN_NEWS_ADMIN_01", "Éléments d'actualités en post-it");
define("LAN_NEWS_ADMIN_02", "Éléments d'actualités affectés");
define("LAN_NEWS_ADMIN_03", "Limiter les éléments d'actualité à une catégorie spécifique");
define("LAN_NEWS_ADMIN_04", "Les éléments affectés sont ceux dont le modèle est 'Menu grille d'actualités'");
define("LAN_NEWS_ADMIN_05", "Nombre d'éléments à afficher");
define("LAN_NEWS_ADMIN_06", "Limite de caractères de titre");
define("LAN_NEWS_ADMIN_07", "Limite de caractères de résumé");
define("LAN_NEWS_ADMIN_08", "Afficher le lien de l'archive");
define("LAN_NEWS_ADMIN_09", "Limites");
define("LAN_NEWS_ADMIN_10", "Nombre d'éléments");
define("LAN_NEWS_ADMIN_11", "Les éléments affectés sont ceux dont le modèle est 'Carrousel d'actualités'");


?>