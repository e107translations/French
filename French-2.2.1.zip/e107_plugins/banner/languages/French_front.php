<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/08/25 13:30:36
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("BANNERLAN_16", "Nom d'utilisateur :");
define("BANNERLAN_17", "Mot de passe :");
define("BANNERLAN_19", "Veuillez entrer votre identifiant client et mot de passe pour continuer");
define("BANNERLAN_20", "Désolé, impossible de trouver ces informations dans la base de données. Pour plus d'informations, veuillez contacter l'administrateur du site.");
define("BANNERLAN_21", "Statistiques de bannières");
define("BANNERLAN_22", "Client");
define("BANNERLAN_23", "ID de la bannière");
define("BANNERLAN_24", "Clics efficaces");
define("BANNERLAN_25", "Clic %");
define("BANNERLAN_26", "Impressions");
define("BANNERLAN_27", "Impressions achetées");
define("BANNERLAN_28", "Impressions abandonnées");
define("BANNERLAN_29", "Aucune bannière");
define("BANNERLAN_30", "Illimité");
define("BANNERLAN_31", "Non applicable");
define("BANNERLAN_34", "Se termine :");
define("BANNERLAN_35", "Adresses IP de clics efficaces");
define("BANNERLAN_36", "Active :");
define("BANNERLAN_37", "Débute :");
define("BANNERLAN_39", "Aucune image assignée à cette bannière.");


?>