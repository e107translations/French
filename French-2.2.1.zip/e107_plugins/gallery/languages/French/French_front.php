<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/04/20 17:19:25
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_GALLERY_FRONT_01", "Clic-droit > Enregistrer le lien comme");
define("LAN_GALLERY_FRONT_02", "Agrandir l'image");


?>