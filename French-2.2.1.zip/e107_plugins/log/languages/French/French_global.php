<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_LOG_NAME", "Statistiques du site");
define("LAN_PLUGIN_LOG_DESCRIPTION", "Cette extension enregistrera toutes les visites de votre site et construira des écrans de statistiques détaillées basés sur les informations recueillies.");
define("LAN_PLUGIN_LOG_CONFIGURE", "Configurer l'enregistrement des statistiques");
define("LAN_PLUGIN_LOG_LINK", "Visites");
