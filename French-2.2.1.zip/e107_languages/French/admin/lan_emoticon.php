<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan


define("EMOLAN_1", "Activation des émoticônes");
define("EMOLAN_3", "Émoticônes");
define("EMOLAN_4", "Activer les émoticônes ?");
define("EMOLAN_5", "Image");
define("EMOLAN_6", "Code de l'émoticône");
define("EMOLAN_7", "Séparer les entrées multiples avec des espaces");
define("EMOLAN_11", "Activer le pack");
define("EMOLAN_13", "Packs installés");
define("EMOLAN_17", "Vous avez un pack d'émoticône présent qui contient des espaces dans le nom, ce qui n'est pas autorisé !");
define("EMOLAN_18", "Veuillez renommer les fichiers suivants afin qu'ils ne contiennent plus d'espaces");
define("EMOLAN_20", "Emplacement");
define("EMOLAN_21", "Erreur de lecture du pack");
define("EMOLAN_22", "Nouveau pack d'émoticônes détecté");
define("EMOLAN_23", "Nouveau pack XML d'émoticônes détecté");
define("EMOLAN_24", "Nouveau pack PHP d'émoticônes détecté");
define("EMOLAN_26", "Re-scanner le pack");
define("EMOLAN_27", "Erreur survenue lors du traitement du pack");
define("EMOLAN_28", "Générer des données XML");
define("EMOLAN_29", "Fichier XML généré");
define("EMOLAN_30", "Erreur d'écriture du fichier XML");
define("EMOLAN_PAGE_TITLE", "Émoticônes");
define("EMOLAN_31", "[x] fichiers trouvés au total");
define("EMOLAN_32", "Pack inconnu détecté");
define("EMOLAN_33", "Format de fichier XML non pris en charge");
define("EMOLAN_34", "Fichiers manquants pour le pack");
define("EMOLAN_35", "- supprimé dans la base de données");
define("EMOLAN_37", "Émoticône non défini");
define("EMOLAN_38", "Valeur vide pour l'émoticône");
