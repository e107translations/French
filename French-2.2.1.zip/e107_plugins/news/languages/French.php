<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/10/13 09:13:48
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("TD_MENU_L1", "Autres articles");
define("TD_MENU_L2", "Autres articles");
define("LAN_NEWSCAT_MENU_TITLE", "Catégories d'articles");
define("LAN_NEWSLATEST_MENU_TITLE", "Derniers articles");
define("LAN_NEWSARCHIVE_MENU_TITLE", "Archive des articles");


?>