<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/01/10 10:48:06
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("WMLAN_00", "Messages de bienvenue");
define("WMLAN_05", "Rendu style thème");
define("WMLAN_06", "Lorsqu'activé, le message sera restitué à l'intérieur d'une boîte");
define("WMLAN_07", "Substituer le système standard pour utiliser le shortcode {WMESSAGE} :");
define("WMLAN_11", "Inclus avec le carrousel");
define("WMLAN_12", "Aide du message d'accueil");
define("WMLAN_13", "Cette page vous permet de définir un message qui apparaîtra en haut de votre page d'accueil aussi longtemps qu'il sera activé. Vous pouvez définir un message différent pour les invités, les membres enregistrés/connectés et les administrateurs.");


?>