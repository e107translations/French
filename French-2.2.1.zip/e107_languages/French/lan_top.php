<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TOP_LAN_0", "Les membres publiant le plus sur le forum");
define("TOP_LAN_1", "Nom d'utilisateur");
define("TOP_LAN_2", "Publications");
define("TOP_LAN_3", "Les membres plubliant le plus de commentaires");
define("TOP_LAN_5", "Les membres plubliant le plus dans la boîte de dialogue");
define("TOP_LAN_6", "Évaluation du site");
define("LAN_1", "Discussion");
define("LAN_2", "Publié par");
define("LAN_3", "Vues");
define("LAN_4", "Réponses");
define("LAN_5", "Dernière publication");
define("LAN_6", "Discussions");
define("LAN_7", "Discussions les plus actives");
define("LAN_8", "Les membres participant le plus");
