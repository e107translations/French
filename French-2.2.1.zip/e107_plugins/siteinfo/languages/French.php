<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("COMPLIANCE_L1", "Conformité W3C");
define("SITEBUTTON_MENU_L1", "Lien vers notre site");
define("POWEREDBY_L1", "Alimenté par");
define("COUNTER_L1", "Les visites des administrateurs ne sont pas totalisées.");
define("COUNTER_L2", "Cette page aujourd'hui ...");
define("COUNTER_L3", "total");
define("COUNTER_L4", "Cette page depuis toujours ...");
define("COUNTER_L5", "unique");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Compteur");
define("COUNTER_L8", "Message à l'administrateur : <b>l'enregistrement des statistiques est désactivé.</b><br />Pour l'activer, vous devez installer l'extension Enregistrement des statistiques depuis le <a href='".e_ADMIN."plugin.php'>gestionnaire d'extensions</a>, puis l'activer à partir de l'<a href='".e_PLUGIN."log/admin_config.php'>écran de configuration</a>.");
