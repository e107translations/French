<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FOR_SCH_LAN_2", "Sélectionnez un forum");
define("FOR_SCH_LAN_4", "Message entier");
define("FOR_SCH_LAN_5", "Dans le cadre du fil de discussion");
