<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("UGFLAN_2", "Activer l'indicateur de maintenance");
define("UGFLAN_4", "Paramètres de maintenance");
define("UGFLAN_5", "Texte à afficher lorsque le site est en maintenance");
define("UGFLAN_6", "Laissez vide pour afficher le message par défaut");
define("UGFLAN_8", "Limiter l'accès aux administrateurs seulement");
define("UGFLAN_9", "Limiter l'accès aux administrateurs principaux seulement");
