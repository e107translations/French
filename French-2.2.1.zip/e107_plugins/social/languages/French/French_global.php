<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/23 11:22:35
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_SOCIAL_DESCR", "Ajoute les options pour remplacer le système e107 de commentaires avec Facebook. Ajoute les flux Twitter à votre site. etc.");
define("LAN_PLUGIN_SOCIAL_SIGNIN", "Se connecter avec :");
define("LAN_PLUGIN_SOCIAL_XUP_SIGNUP", "Se connecter avec votre compte [x]");
define("LAN_PLUGIN_SOCIAL_XUP_REG", "S'inscrire avec votre compte [x]");
define("LAN_PLUGIN_SOCIAL_NAME", "Social");


?>