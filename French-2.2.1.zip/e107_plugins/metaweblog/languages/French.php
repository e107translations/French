<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("XMLRPC_ADMIN_001", "Menu principal");
define("XMLRPC_CONFIG_001", "MetaWeblog :: Configuration");
define("XMLRPC_PREFS_001", "eXMLRPC - Options");
define("XMLRPC_PREFS_002", "eXMLRPC");
define("XMLRPC_PREFS_003", "Type de rendu d'actualités (0,1,2,3)");
define("XMLRPC_PREFS_004", "Dossier de téléchargement (e_FILE /)");
define("XMLRPC_PREFS_005", "ID de blog pour le client");
define("XMLRPC_PREFS_006", "Nom de blog pour le client");
define("XMLRPC_HELP_001", "Instructions");
define("XMLRPC_HELP_010", "Général");
define("XMLRPC_HELP_011", "Cette extension en elle-même ne fait rien ! C'est seulement pour paramétrer quelques variables XMLRPC. Pointez votre logiciel client XMLRPC (par ex. Windows Live Writer) vers <strong>".SITEURL."metaweblog.php</strong> et renseignez les valeurs nécessaires. Attention ! Cette extension est expérimentale !");
define("XMLRPC_HELP_020", "Titre de l'extension");
define("XMLRPC_HELP_021", "Peu importe que l'extension ne renvoie rien");
define("XMLRPC_HELP_030", "Type de rendu d'actualités");
define("XMLRPC_HELP_031", "Important ! Type de rendu d'actualités par défaut");
define("XMLRPC_HELP_040", "Dossier de téléchargement pour les fichiers");
define("XMLRPC_HELP_041", "C'est toujours un dossier enfant d'e107_files !");
define("XMLRPC_HELP_050", "Id du blog pour le client");
define("XMLRPC_HELP_051", "ID du blog pour le client XMLRPC (n'importe quelle chaîne de caractères)");
define("XMLRPC_HELP_060", "Nom du blog pour le client");
define("XMLRPC_HELP_061", "Nom du blog pour le client XMLRPC (n'importe quelle chaîne de caractères)");
