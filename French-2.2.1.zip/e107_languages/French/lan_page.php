<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PAGE_1", "La liste de page listant n'est pas activée");
define("LAN_PAGE_2", "Il n'y a pas de page");
define("LAN_PAGE_3", "La page demandée n'existe pas");
define("LAN_PAGE_4", "Évaluer cette page");
define("LAN_PAGE_5", "Merci pour l'évaluation de cette page");
define("LAN_PAGE_6", "Vous n'êtes pas autorisé à afficher cette page");
define("LAN_PAGE_7", "Mot de passe incorrect");
define("LAN_PAGE_8", "Page protégée par un mot de passe");
define("LAN_PAGE_10", "Soumettre");
define("LAN_PAGE_11", "Liste des pages");
define("LAN_PAGE_12", "Page non valide");
define("LAN_PAGE_13", "Page");
define("LAN_PAGE_14", "Autres articles");
define("LAN_PAGE_15", "Articles");
define("LAN_PAGE_16", "Il n'y a pas de chapitre dans ce livre");
