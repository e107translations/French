<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_DOWNL_01", "Téléchargements - options des téléchargements modifiées");
define("LAN_AL_DOWNL_02", "Téléchargements - options des téléchargements modifiées");
define("LAN_AL_DOWNL_03", "Téléchargements - limite ajoutée");
define("LAN_AL_DOWNL_04", "Téléchargements - log 04");
define("LAN_AL_DOWNL_05", "Téléchargements - log 05");
define("LAN_AL_DOWNL_06", "Téléchargements - log 06");
define("LAN_AL_DOWNL_07", "Téléchargements - log 07");
define("LAN_AL_DOWNL_08", "Téléchargements - log 08");
define("LAN_AL_DOWNL_09", "Téléchargements - log 09");
define("LAN_AL_DOWNL_10", "Téléchargements - limite mise à jour");
define("LAN_AL_DOWNL_11", "Téléchargements - limite supprimée");
