<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("FMLAN_12", "fichier");
define("FMLAN_13", "fichiers");
define("FMLAN_14", "répertoire");
define("FMLAN_15", "répertoires");
define("FMLAN_16", "Répertoire racine");
define("FMLAN_18", "Taille");
define("FMLAN_19", "Dernière modification");
define("FMLAN_21", "Télécharger un fichier dans ce répertoire");
define("FMLAN_22", "Télécharger");
define("FMLAN_29", "Chemin");
define("FMLAN_30", "Niveau supérieur");
define("FMLAN_31", "dossier");
define("FMLAN_32", "Sélectionnez un répertoire");
define("FMLAN_34", "Choix du répertoire");
define("FMLAN_35", "Répertoire des fichiers");
define("FMLAN_38", "Fichier déplacé avec succès vers");
define("FMLAN_39", "Impossible de déplacer le fichier vers");
define("FMLAN_40", "Répertoire des images des articles");
define("FMLAN_43", "Supprimer les fichiers sélectionnés");
define("FMLAN_46", "Veuillez confirmer que vous souhaitez supprimer les fichiers sélectionnés.");
define("FMLAN_47", "Téléchargements utilisateur");
define("FMLAN_48", "Déplacer la sélection vers");
define("FMLAN_49", "Veuillez confirmer que vous souhaitez déplacer les fichiers sélectionnés.");
define("FMLAN_50", "Déplacer");
define("FMLAN_51", "Erreur non identifiée");
