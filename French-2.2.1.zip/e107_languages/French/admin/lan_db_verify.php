<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("DBVLAN_1", "Impossible de lire le fichier de données sql<br /><br />.Veuillez vous assurer que le fichier <b>core_sql.php</b> existe dans le répertoire <b>/e107_core/sql</b>.");
define("DBVLAN_4", "Table");
define("DBVLAN_5", "Champ");
define("DBVLAN_6", "Statut");
define("DBVLAN_7", "Notes");
define("DBVLAN_8", "Incompatibilité de");
define("DBVLAN_9", "Actuellement");
define("DBVLAN_10", "devrait être");
define("DBVLAN_11", "Champ absent !");
define("DBVLAN_12", "Champ supplémentaire !");
define("DBVLAN_13", "Table manquante !");
define("DBVLAN_14", "Choisissez la(les) table(s) pour valider");
define("DBVLAN_15", "Commencer à vérifier");
define("DBVLAN_16", "Vérification SQL");
define("DBVLAN_19", "Tentez de résoudre");
define("DBVLAN_21", "Résoudre les éléments sélectionnés");
define("DBVLAN_22", "[x] n'est pas accessible en écriture");
define("DBVLAN_23", "Utilitaires de base de données");
define("DBVLAN_24", "Veuillez choisir une action.");
define("DBVLAN_25", "Index manquant !");
define("DBVLAN_26", "[x] table(s) présente(nt) des problèmes.");
