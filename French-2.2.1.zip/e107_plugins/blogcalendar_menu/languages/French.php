<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("BLOGCAL_L1", "Articles par mois");
define("BLOGCAL_L2", "Archive");
define("BLOGCAL_1", "Éléments d'articles");
define("BLOGCAL_CONF1", "Mois/ligne");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF4", "Configuration du menu BlogCal");
define("BLOGCAL_ARCHIV1", "Sélectionnez l'archive");
