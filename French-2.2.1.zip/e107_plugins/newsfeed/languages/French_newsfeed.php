<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NFLAN_29", "Flux RSS disponible");
define("NFLAN_31", "Retour à la liste de flux RSS");
define("NFLAN_33", "Date de publication :");
define("NFLAN_34", "inconnu");
define("NFLAN_38", "Titres");
define("NFLAN_39", "Détails");
define("NFLAN_48", "Impossible d'enregistrer les données brutes dans la base de données.");
