<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/05/23 10:41:00
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LANDT_01", "année");
define("LANDT_02", "mois");
define("LANDT_03", "semaine");
define("LANDT_04", "jour");
define("LANDT_05", "heure");
define("LANDT_06", "minute");
define("LANDT_07", "seconde");
define("LANDT_01s", "ans");
define("LANDT_02s", "mois");
define("LANDT_03s", "semaines");
define("LANDT_04s", "jours");
define("LANDT_05s", "heures");
define("LANDT_06s", "minutes");
define("LANDT_07s", "secondes");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sec");
define("LANDT_09s", "secs");
define("LANDT_AGO", "Depuis");
define("LANDT_IN", "en");
define("LANDT_10", "Juste maintenant");
define("LANDT_XAGO", "[x] avant");
define("LANDT_INX", "dans [x]");
