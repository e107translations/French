<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/09/25 11:06:39
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("FBLAN_08", "Texte du message");
define("FBLAN_12", "Mode");
define("FBLAN_13", "Portée aléatoire des messages");
define("FBLAN_14", "Afficher seulement ce message");
define("FBLAN_22", "Type de rendu");
define("FBLAN_23", "Dans la boîte de thème");
define("FBLAN_24", "Plein");
define("FBLAN_25", "Il n'y a aucun élément featurebox assigné au modèle [x].");
define("FBLAN_26", "Image/Vidéo");
define("FBLAN_27", "Lien image");
define("FBLAN_28", "Catégorie de menu featurebox");
define("FBLAN_29", "Catégorie à utiliser pour le menu featurebox");
define("FBLAN_30", "Modèle de catégorie");
define("FBLAN_31", "Aléatoire");
define("FBLAN_32", "Paramètres (optionnel)");
define("FBLAN_33", "Paramètres Javascript optionnels (format sujet à changement)");
define("FBLAN_34", "Non attribué");
define("FBLAN_35", "Carrousel");
define("FBLAN_36", "Onglets");
