<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2016/09/01 11:07:17
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Soumettre un article");
define("LAN_7", "Nom :");
define("LAN_112", "Adresse mail :");
define("LAN_133", "Merci");
define("LAN_134", "Votre article a été soumis pour examen à l'un des administrateurs du site.");
define("LAN_135", "Articles :");
define("LAN_136", "Soumettre un article");
define("NWSLAN_6", "Catégorie");
define("NWSLAN_10", "Aucune catégorie d'articles");
define("NWSLAN_11", "Vous n'avez pas accès à cette zone ou bien vous n'êtes pas connecté actuellement.");
define("NWSLAN_12", "Accès refusé.");
define("SUBNEWSLAN_1", "Vous devez inclure un title.\\n");
define("SUBNEWSLAN_2", "Vous devez inclure du texte dans le corps de l'article.\\n");
define("SUBNEWSLAN_3", "Votre pièce jointe doit être un fichier jpg, gif ou png");
define("SUBNEWSLAN_4", "Fichier trop volumineux");
define("SUBNEWSLAN_5", "Fichier image");
define("SUBNEWSLAN_6", "(jpg, gif ou png)");
define("SUBNEWSLAN_7", "Vous devez donner votre nom et votre adresse mail");
define("SUBNEWSLAN_8", "Erreur de téléchargement de l'image");
define("SUBNEWSLAN_9", "Mots-clés");
define("SUBNEWSLAN_10", "Résumé");
define("SUBNEWSLAN_11", "Balise meta description");
define("SUBNEWSLAN_12", "Utilisé par Facebook etc.");
define("SUBNEWSLAN_13", "URL des médias");


?>