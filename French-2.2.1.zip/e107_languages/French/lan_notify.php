<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NT_LAN_US_1", "Inscription utilisateur");
define("NT_LAN_UV_1", "Inscription utilisateur vérifiée");
define("NT_LAN_UV_2", "ID utilisateur : ");
define("NT_LAN_UV_3", "Nom de connexion utilisateur : ");
define("NT_LAN_UV_4", "IP utilisateur : ");
define("NT_LAN_LI_1", "Utilisateur connecté");
define("NT_LAN_LO_1", "Utilisateur déconnecté");
define("NT_LAN_LO_2", " déconnecté du site");
define("NT_LAN_FL_1", "Exclusion pour cause de flood");
define("NT_LAN_FL_2", "Adresse IP exclue pour cause de flood");
define("NT_LAN_SN_1", "Article soumis");
define("NT_LAN_ML_1", "Mail en vrac envoyé complètement");
define("NT_LAN_NU_1", "Mis(e) à jour");
define("NT_LAN_ND_1", "Article supprimé");
define("NT_LAN_ND_2", "ID article supprimé");
