<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("TRACKBACK_L7", "Activer les rétroliens");
define("TRACKBACK_L8", "Texte de l'URL du rétrolien");
define("TRACKBACK_L10", "Paramètres du rétrolien");
define("TRACKBACK_L11", "Adresse du rétrolien pour ce message :");
define("TRACKBACK_L12", "Aucun rétrolien pour cet élément");
define("TRACKBACK_L13", "Rétroliens modérés");
define("TRACKBACK_L16", "Rétrolien");
