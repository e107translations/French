<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Flux RSS");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "Cette extension retrouvera les flux RSS d'autres sites web et les affichera selon vos préférences.");
