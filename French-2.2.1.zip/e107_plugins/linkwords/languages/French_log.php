<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_AL_LINKWD_00", "Message concernant le mot-lien");
define("LAN_AL_LINKWD_01", "Mot-lien  ajouté");
define("LAN_AL_LINKWD_02", "Mot-lien  modifié");
define("LAN_AL_LINKWD_03", "Mot-lien  supprimé");
define("LAN_AL_LINKWD_04", "Options du mot-lien mises à jour");
define("LAN_AL_LINKWD_05", "Mise à jour de la version des mots-liens");
