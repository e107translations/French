<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Boîte de discussion");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Menu de la boîte de discussion");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Publications de la boîte de discussion");
define("LAN_AL_CHBLAN_01", "Réglages de la boîte de discussion mis à jour");
define("LAN_AL_CHBLAN_02", "Boîte de discussion nettoyée");
define("LAN_AL_CHBLAN_03", "Messages de la boîte de discussion recalculés");
define("LAN_AL_CHBLAN_04", "");
define("LAN_AL_CHBLAN_05", "");
define("NT_LAN_CB_1", "Événements de la boîte de discussion");
define("NT_LAN_CB_2", "Message publié");
define("NT_LAN_CB_3", "Publié par");
define("NT_LAN_CB_5", "Message");
define("NT_LAN_CB_6", "Message de la boîte de discussion publié");
