<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/09/25 11:23:06
|
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/

define("LIST_MENU_1", "ajouts récents");
define("LIST_MENU_2", "par");
define("LIST_MENU_3", "le");
define("LIST_MENU_4", "dans");
define("LIST_MENU_5", "jours");
define("LIST_MENU_6", "afficher le contenu pendant combien de jours ?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "articles");
define("LIST_NEWS_2", "aucun article");
define("LIST_COMMENT_1", "commentaires");
define("LIST_COMMENT_2", "aucun commentaire");
define("LIST_COMMENT_3", "articles");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "sondage");
define("LIST_COMMENT_6", "documents");
define("LIST_COMMENT_7", "traqueur de bugs");
define("LIST_COMMENT_8", "contenu");
define("LIST_COMMENT_9", "");
define("LIST_COMMENT_10", "idées");
define("LIST_MEMBER_1", "membres");
define("LIST_MEMBER_2", "aucun membre");
define("LIST_CONTENT_1", "contenu");
define("LIST_CONTENT_2", "aucun contenu dans");
define("LIST_CONTENT_3", "aucune catégorie de contenu valide");
define("LIST_CHATBOX_1", "boîte de discussion");
define("LIST_CHATBOX_2", "aucun message dans la boîte de discussion");
define("LIST_CALENDAR_1", "calendrier");
define("LIST_CALENDAR_2", "aucun événement de calendrier");
define("LIST_LINKS_1", "liens");
define("LIST_LINKS_2", "aucun lien");
define("LIST_FORUM_1", "Forum");
define("LIST_FORUM_2", "aucun message du forum");
define("LIST_FORUM_3", "vues :");
define("LIST_FORUM_4", "réponses :");
define("LIST_FORUM_5", "dernier message :");
define("LIST_FORUM_6", "le :");
define("LIST_LAN_1", "aucun élément dans");
define("LIST_DOWNLOAD_1", "téléchargements");
define("LIST_DOWNLOAD_2", "aucun téléchargement");


?>