<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_dl_61", "Erreur lors du téléchargement");
  define("LAN_dl_62", "Vous ne pouvez pas télécharger ce fichier car vous avez dépassé votre quota de téléchargement");
  define("LAN_dl_63", "Vous n'avez pas les autorisations adéquates pour télécharger ce fichier.");
  define("LAN_dl_64", "Retour");
  define("LAN_dl_65", "Fichier non trouvé");
  ?>
