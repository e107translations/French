<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LANMAILH_1", "Produit par le système de sites web e107");
define("LANMAILH_2", "Il s'agit d'un message à plusieurs parties au format MIME.");
define("LANMAILH_3", " n'est pas correctement mise en forme");
define("LANMAILH_4", "Le serveur a rejeté l'adresse");
define("LANMAILH_5", "Aucune réponse du serveur");
define("LANMAILH_6", "Ne peut pas trouver le serveur de messagerie.");
define("LANMAILH_7", " semble être valide.");
