<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_dl_1", "(Restreint)");
define("LAN_dl_4", "Fichiers disponibles : ");
define("LAN_dl_5", "Taille totale des fichiers : ");
define("LAN_dl_6", "Fichiers téléchargés : ");
define("LAN_dl_8", "Obtenir");
define("LAN_dl_9", "Retour à la liste des catégories");
define("LAN_dl_13", "Non évalué");
define("LAN_dl_14", "Évaluer ce téléchargement");
define("LAN_dl_16", "Téléchargement(s) de");
define("LAN_dl_29", "téléchargement de");
define("LAN_dl_30", "Mail de l'auteur");
define("LAN_dl_31", "Site web de l'auteur");
define("LAN_dl_36", "Nouveaux téléchargements");
define("LAN_dl_40", "Cliquez ici pour la capture d'écran");
define("LAN_dl_43", "voter");
define("LAN_dl_44", "votes");
define("LAN_dl_45", "Rapport un téléchargement rompu");
define("LAN_dl_46", "Cliquez ici pour télécharger");
define("LAN_dl_47", "Un message a été signalé");
define("LAN_dl_48", "Le téléchargement a été signalé à l'administrateur.<br>Merci.");
define("LAN_dl_49", "Cliquez ici pour retourner aux téléchargements");
define("LAN_dl_50", "Téléchargement rompu signalé");
define("LAN_dl_51", "Signaler le téléchargement : ");
define("LAN_dl_53", "Cliquer pour voir les téléchargements");
define("LAN_dl_54", "Un administrateur sera informé de ce téléchargement, veuillez laisser un message si vous le sentez nécessaire.");
define("LAN_dl_55", "<b>Ne pas</b> utiliser ce formulaire pour contacter l'admin pour toute autre raison.");
define("LAN_dl_57", "signalé par");
define("LAN_dl_58", "Le téléchargement suivant a été signalé comme rompu à partir du site");
define("LAN_dl_59", "Signalé par :");
define("LAN_dl_60", "Signalement de téléchargement rompu de");
define("LAN_dl_62", "Vous avez été bloqué dans le téléchargement de ce fichier ; vous avez dépassé votre quota de téléchargement");
define("LAN_dl_63", "Vous n'avez pas les autorisations nécessaires pour télécharger ce fichier.");
define("LAN_dl_66", "Sélectionnez un site miroir de téléchargement");
define("LAN_dl_67", "Sélectionnez un site miroir ...");
define("LAN_dl_68", "Site miroir hôte");
define("LAN_dl_72", "Demande de fichier :");
define("LAN_dl_73", "Téléchargements de ce site miroir :");
define("LAN_dl_74", "Nombre total de téléchargements de ce site miroir :");
define("LAN_dl_75", "aucune image disponible");
define("LAN_dl_77", "Téléchargements");
define("LAN_dl_78", "Ce téléchargement a été désactivé ou interrompu. Veuillez vérifier dans [link =--LINK--]la zone des téléchargements[/LINK] pour une version plus récente.");
