<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Site temporairement fermé");
define("LAN_SITEDOWN_00", "est temporairement fermé");
define("LAN_SITEDOWN_01", "Nous avons fermé temporairement le site pour cause de maintenance. Cela ne devrait pas être trop long. Veuillez revenir bientôt et nous excuser pour la gêne occasionnée.");
