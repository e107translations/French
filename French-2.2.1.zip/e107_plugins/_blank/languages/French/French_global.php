<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("LAN_PLUGIN__BLANK_NAME", "Extension vierge");
define("LAN_PLUGIN__BLANK_DIZ", "Une extension vierge pour vous aider à vous lancer dans le développement d'une extension. Plus de détails peuvent être ajoutés ici.");
define("LAN_PLUGIN__BLANK_LINK", "Lien vierge");
