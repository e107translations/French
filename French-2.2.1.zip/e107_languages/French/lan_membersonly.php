<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("PAGE_NAME", "Réservé aux membres");
define("LAN_MEMBERS_0", "zone d'accès restreint");
define("LAN_MEMBERS_1", "Il s'agit d'une zone d'accès restreint.");
define("LAN_MEMBERS_2", "Pour y accèder, veuillez vous [log in]");
define("LAN_MEMBERS_3", "ou [register] en tant que membre.");
define("LAN_MEMBERS_4", "Cliquez ici pour retourner à la page principale.");
