<?php

// Bing-Translated Language file 
// Generated for e107 v2.x by the Multi-Language Plugin
// https://github.com/e107inc/multilan

define("NP_1", "Page précédente");
define("NP_2", "Page suivante");
define("LAN_NP_FIRST", "premier");
define("LAN_NP_URLFIRST", "Aller à la première page");
define("LAN_NP_PREVIOUS", "précédent");
define("LAN_NP_URLPREVIOUS", "Aller à la page précédente");
define("LAN_NP_NEXT", "suivant");
define("LAN_NP_URLNEXT", "Aller à la page suivante");
define("LAN_NP_LAST", "dernier");
define("LAN_NP_URLLAST", "Aller à la dernière page");
define("LAN_NP_GOTO", "Aller à la page [x]");
define("LAN_NP_URLCURRENT", "Actuellement vu");
define("NP_CAPTION", "Page [x] sur [y]");
